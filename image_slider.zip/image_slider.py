# Contributed By : Sravan Kumar
from itertools import cycle
import tkinter as tk


class ImageSlider():
    def __init__(self, master, image_files, delay):
        self.root = master
        self.root.geometry('400x300')
        self.delay = delay
        self.root.title("Image Slider Using Python")
        # Self.pictures stores all images
        self.root.pictures = cycle((tk.PhotoImage(file=image), image) for image in image_files)
        self.root.pictures_display = tk.Label(master)
        self.root.pictures_display.pack()

    def show_slides(self):
        # We cycle through images using Iterator
        img_object, img_name = next(self.root.pictures)
        self.root.pictures_display.config(image=img_object)
        self.root.after(self.delay, self.show_slides)

    def run(self):
        self.root.mainloop()


# set milliseconds time between sliders
delay = 3500

# Collect Bunch of Images and store them in same script.
# Note : Use .png images format
image_files = ['code1.png', 'code2.png', 'code3.png', 'code4.png']
root = tk.Tk()
app = ImageSlider(root, image_files, delay)
app.show_slides()
app.run()
